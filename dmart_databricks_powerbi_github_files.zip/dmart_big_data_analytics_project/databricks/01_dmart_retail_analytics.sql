-- ============================================================================
-- DMart-inspired Retail Sales Analytics | Databricks SQL + Delta Lake
-- Dataset: 100,000 synthetic sales-line records, 15 columns, calendar year 2025
-- IMPORTANT: This is simulated educational data, not actual DMart transaction data.
--
-- BEFORE RUNNING:
-- 1. In Databricks, create a Unity Catalog volume for the CSV (or use an
--    existing volume where you have READ VOLUME permission).
-- 2. Upload dmart_retail_sales_synthetic_100000.csv into that volume.
-- 3. Replace the catalog/schema/volume path below if your names differ.
-- 4. Run this script in a Databricks SQL warehouse or a SQL notebook.
-- ============================================================================

-- SECTION 1: Create the project schema.
CREATE SCHEMA IF NOT EXISTS main.dmart_analytics;
USE CATALOG main;
USE SCHEMA dmart_analytics;

-- SECTION 2: Create the raw Delta table with an explicit schema.
CREATE TABLE IF NOT EXISTS retail_sales_raw (
    Transaction_ID STRING,
    Transaction_Date DATE,
    Transaction_Time STRING,
    Store_ID STRING,
    City STRING,
    Customer_ID STRING,
    Product_ID STRING,
    Product_Name STRING,
    Product_Category STRING,
    Brand STRING,
    Quantity INT,
    Unit_Price DECIMAL(12, 2),
    Discount_Percent DECIMAL(5, 2),
    Payment_Method STRING,
    Total_Amount DECIMAL(14, 2)
)
USING DELTA;

-- SECTION 3: Load the CSV from a Unity Catalog volume.
-- Replace this path with your actual volume path.
-- Example: /Volumes/main/dmart_analytics/retail_files/<filename>.csv
COPY INTO main.dmart_analytics.retail_sales_raw
FROM '/Volumes/main/dmart_analytics/retail_files/dmart_retail_sales_synthetic_100000.csv'
FILEFORMAT = CSV
FORMAT_OPTIONS (
    'header' = 'true',
    'dateFormat' = 'yyyy-MM-dd'
);

-- COPY INTO is idempotent: the same file is normally skipped on a repeat run.
-- Do not add COPY_OPTIONS ('force' = 'true') unless you deliberately want to reload it.

-- SECTION 4: Create a view of records that fail basic data-quality rules.
CREATE OR REPLACE VIEW retail_sales_rejected_rows AS
SELECT *
FROM retail_sales_raw
WHERE Transaction_ID IS NULL
   OR Transaction_Date IS NULL
   OR Store_ID IS NULL
   OR Product_ID IS NULL
   OR Customer_ID IS NULL
   OR Quantity IS NULL
   OR Quantity <= 0
   OR Unit_Price IS NULL
   OR Unit_Price < 0
   OR Discount_Percent IS NULL
   OR Discount_Percent < 0
   OR Discount_Percent > 100
   OR Total_Amount IS NULL
   OR Total_Amount < 0
   OR ABS(
        Total_Amount - ROUND(
            Quantity * Unit_Price * (1 - Discount_Percent / 100), 2
        )
      ) >= 0.02;

-- SECTION 5: Create the cleaned analytical Delta table.
CREATE OR REPLACE TABLE retail_sales_clean
USING DELTA
AS
SELECT
    Transaction_ID,
    Transaction_Date,
    Transaction_Time,
    Store_ID,
    City,
    Customer_ID,
    Product_ID,
    Product_Name,
    Product_Category,
    Brand,
    Quantity,
    Unit_Price,
    Discount_Percent,
    Payment_Method,
    Total_Amount,
    CAST(Quantity * Unit_Price AS DECIMAL(14, 2)) AS Gross_Amount,
    CAST(Quantity * Unit_Price - Total_Amount AS DECIMAL(14, 2)) AS Discount_Amount,
    YEAR(Transaction_Date) AS Sales_Year,
    MONTH(Transaction_Date) AS Sales_Month,
    DATE_FORMAT(Transaction_Date, 'yyyy-MM') AS Sales_Year_Month
FROM retail_sales_raw
WHERE Transaction_ID IS NOT NULL
  AND Transaction_Date IS NOT NULL
  AND Store_ID IS NOT NULL
  AND Product_ID IS NOT NULL
  AND Customer_ID IS NOT NULL
  AND Quantity > 0
  AND Unit_Price >= 0
  AND Discount_Percent BETWEEN 0 AND 100
  AND Total_Amount >= 0
  AND ABS(
        Total_Amount - ROUND(
            Quantity * Unit_Price * (1 - Discount_Percent / 100), 2
        )
      ) < 0.02;

-- SECTION 6: Data-quality and load checks.
SELECT 'raw_rows' AS metric, COUNT(*) AS metric_value
FROM retail_sales_raw
UNION ALL
SELECT 'clean_rows' AS metric, COUNT(*) AS metric_value
FROM retail_sales_clean
UNION ALL
SELECT 'rejected_rows' AS metric, COUNT(*) AS metric_value
FROM retail_sales_rejected_rows;

SELECT
    COUNT(*) AS sales_records,
    COUNT(DISTINCT Transaction_ID) AS distinct_transaction_ids,
    COUNT(DISTINCT Customer_ID) AS distinct_customers,
    COUNT(DISTINCT Product_ID) AS distinct_products,
    COUNT(DISTINCT Store_ID) AS distinct_stores,
    SUM(Quantity) AS units_sold,
    ROUND(SUM(Total_Amount), 2) AS net_sales_revenue
FROM retail_sales_clean;

-- SECTION 7: Business-analysis views for Power BI or SQL exploration.
CREATE OR REPLACE VIEW monthly_sales_summary AS
SELECT
    Sales_Year,
    Sales_Month,
    Sales_Year_Month,
    COUNT(*) AS sales_records,
    SUM(Quantity) AS units_sold,
    ROUND(SUM(Gross_Amount), 2) AS gross_sales,
    ROUND(SUM(Discount_Amount), 2) AS discount_amount,
    ROUND(SUM(Total_Amount), 2) AS net_sales_revenue
FROM retail_sales_clean
GROUP BY Sales_Year, Sales_Month, Sales_Year_Month;

CREATE OR REPLACE VIEW category_sales_summary AS
SELECT
    Product_Category,
    COUNT(*) AS sales_records,
    SUM(Quantity) AS units_sold,
    ROUND(SUM(Total_Amount), 2) AS net_sales_revenue,
    ROUND(AVG(Discount_Percent), 2) AS average_discount_percent
FROM retail_sales_clean
GROUP BY Product_Category;

CREATE OR REPLACE VIEW store_sales_summary AS
SELECT
    Store_ID,
    City,
    COUNT(*) AS sales_records,
    COUNT(DISTINCT Customer_ID) AS distinct_customers,
    SUM(Quantity) AS units_sold,
    ROUND(SUM(Total_Amount), 2) AS net_sales_revenue
FROM retail_sales_clean
GROUP BY Store_ID, City;

CREATE OR REPLACE VIEW payment_method_summary AS
SELECT
    Payment_Method,
    COUNT(*) AS sales_records,
    ROUND(SUM(Total_Amount), 2) AS net_sales_revenue,
    ROUND(100.0 * SUM(Total_Amount) / SUM(SUM(Total_Amount)) OVER (), 2) AS revenue_share_percent
FROM retail_sales_clean
GROUP BY Payment_Method;

CREATE OR REPLACE VIEW top_products_summary AS
SELECT
    Product_ID,
    Product_Name,
    Product_Category,
    Brand,
    SUM(Quantity) AS units_sold,
    ROUND(SUM(Total_Amount), 2) AS net_sales_revenue
FROM retail_sales_clean
GROUP BY Product_ID, Product_Name, Product_Category, Brand;

-- SECTION 8: Example analysis queries.
-- 8A. Top 10 products by net revenue.
SELECT *
FROM top_products_summary
ORDER BY net_sales_revenue DESC
LIMIT 10;

-- 8B. Product-category performance.
SELECT *
FROM category_sales_summary
ORDER BY net_sales_revenue DESC;

-- 8C. Store performance.
SELECT *
FROM store_sales_summary
ORDER BY net_sales_revenue DESC;

-- 8D. Monthly sales trend.
SELECT *
FROM monthly_sales_summary
ORDER BY Sales_Year, Sales_Month;

-- 8E. Payment-method mix.
SELECT *
FROM payment_method_summary
ORDER BY net_sales_revenue DESC;

-- SECTION 9: Delta Lake history for the cleaned table.
DESCRIBE HISTORY main.dmart_analytics.retail_sales_clean;
