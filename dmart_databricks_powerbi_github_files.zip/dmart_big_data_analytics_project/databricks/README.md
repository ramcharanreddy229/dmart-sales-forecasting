# Databricks SQL

`01_dmart_retail_analytics.sql` creates the project schema, loads the CSV into a raw Delta table, applies basic validation, creates a cleaned Delta table, and builds analytical views.

## Before running

1. Create or choose a Unity Catalog catalog and schema. The sample script uses `main.dmart_analytics`.
2. Create a Unity Catalog volume named `retail_files` in that schema, or use an existing volume.
3. Upload `dmart_retail_sales_synthetic_100000.csv` to the volume.
4. Update the `COPY INTO` path in the SQL file to the exact path shown in your workspace.
5. Run the script in a Databricks SQL warehouse or SQL notebook.

The script assumes the source CSV contains the 15 column headers in the supplied dataset. `COPY INTO` is idempotent by default and skips files already loaded. If your workspace does not have Unity Catalog volumes or the required permissions, use the workspace's supported file upload/storage method and update the source path.

The data is synthetic and for educational use; it is not actual DMart sales data.
