# Databricks and Power BI GitHub files

This project includes runnable starter assets for Databricks SQL and Power BI:

- `databricks/01_dmart_retail_analytics.sql` — create/load/clean Delta tables and build analysis views.
- `powerbi/01_DMart_RetailSales_Measures.dax` — date table, calculated columns, and dashboard measures.
- `powerbi/02_Databricks_Source_Query.sql` — SQL query to retrieve the cleaned Delta table for Power BI.
- Folder READMEs explain setup and naming assumptions.

The CSV is synthetic retail data created for a DMart-inspired academic case study. Do not represent it as actual company data. Update the Databricks catalog, schema, volume path, and Power BI table name to match your environment.
