# Power BI resources

- `01_DMart_RetailSales_Measures.dax`: DAX calculated date table, date columns, KPI measures, and visual suggestions.
- `02_Databricks_Source_Query.sql`: SQL source query for the cleaned Delta table in Databricks.

## Setup

1. Connect Power BI Desktop to Databricks using the Databricks connector, or import the supplied CSV directly for a local-only workflow.
2. Load `main.dmart_analytics.retail_sales_clean` and rename the imported fact table to `RetailSales` (or update the table name in the DAX formulas).
3. Ensure `Transaction_Date` is Date type and Quantity, Unit_Price, Discount_Percent, and Total_Amount are numeric.
4. Create the `Calendar` calculated table and its calculated columns using the DAX file.
5. Create a one-to-many relationship from `Calendar[Date]` to `RetailSales[Transaction_Date]` and mark Calendar as the date table.
6. Add the measures one at a time via Modeling > New measure.

Power BI business measures are written in DAX, not SQL. The SQL file is the query used to retrieve the Databricks table. The dataset contains one unique Transaction_ID per row, so Sales Records must not be described as invoice count.
