-- Optional source query for Power BI's Databricks connector.
-- Connect to your Databricks SQL warehouse and use this query as the native
-- SQL statement, or select the same table in Navigator.
-- Replace catalog/schema if you changed them in the Databricks SQL script.

SELECT
    Transaction_ID,
    Transaction_Date,
    Transaction_Time,
    Store_ID,
    City,
    Customer_ID,
    Product_ID,
    Product_Name,
    Product_Category,
    Brand,
    Quantity,
    Unit_Price,
    Discount_Percent,
    Payment_Method,
    Total_Amount,
    Gross_Amount,
    Discount_Amount,
    Sales_Year,
    Sales_Month,
    Sales_Year_Month
FROM main.dmart_analytics.retail_sales_clean;
